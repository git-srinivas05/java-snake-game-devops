package com.snakegame;

public class SnakeGame {
    public static void main(String[] args) {
        new GameFrame();
    }
}

